Dear Friends,

Thank you for purchasing The UX Reader eBook. We originally distributed our eBook in EPUB format only. By popular demand, we've converted the EPUB to Kindle (.mobi) and PDF formats. For the best reading experience we still recommend using the EPUB file wherever possible.

Happy Reading,
@MailChimpUX